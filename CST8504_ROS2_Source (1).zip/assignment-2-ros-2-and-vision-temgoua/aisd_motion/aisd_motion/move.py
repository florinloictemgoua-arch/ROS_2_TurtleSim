"""Map fingertip coordinates to forward speed and yaw rate."""

import rclpy
from aisd_msgs.msg import Hand
from geometry_msgs.msg import Twist
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node


class Move(Node):
    def __init__(self):
        super().__init__('move')
        self.vel_publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        self.subscription = self.create_subscription(
            Hand, 'cmd_hand', self.listener_callback, 10
        )

    def listener_callback(self, message):
        twist = Twist()

        # The center deadband includes both boundary values.
        if message.xindex > 0.55:
            twist.angular.z = -0.1
        elif message.xindex < 0.45:
            twist.angular.z = 0.1

        # Compare fingertip positions independently of the steering rule.
        # Default Twist components are zero, including when the tips align.
        if message.xindex > message.xpinky:
            twist.linear.x = 0.5

        self.vel_publisher.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    node = Move()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
