# CST8504 Assignment 2 ROS 2 Vision

The camera feeds `image_publisher` → `/video_frames` (Image) → `hands` →
`/cmd_hand` (Hand) → `move` → `/cmd_vel` (Twist) → Turtlesim after remapping.

## Build on the Ubuntu 22.04 ROS 2 Humble VM

Put this repository, or its three package folders, under `~/ros2_ws/src`.
Keep just one copy of each package in that workspace. In the **Ubuntu terminal**:

```bash
source /opt/ros/humble/setup.bash
cd ~/ros2_ws
sudo apt install python3-pip ros-humble-turtlesim
rosdep update
rosdep install -i --from-paths src --rosdistro humble -y --skip-keys python3-mediapipe-pip
python3 -m pip install --user -r src/assignment-2-ros-2-and-vision-temgoua/requirements-vision.txt
python3 -c 'import cv2, numpy, mediapipe as mp; from cv_bridge import CvBridge; print(cv2.__version__, numpy.__version__, mp.__version__, mp.solutions.hands.Hands)'
colcon build --packages-up-to aisd_vision aisd_motion
```

Adjust the requirements path if the repository folder has a different name.
The manual pip step fulfills the skipped MediaPipe dependency with a version
selected for the legacy `mp.solutions.hands` API and pins NumPy to the
assignment's version. If rosdep reports it was never initialized, run
`sudo rosdep init` once and then repeat `rosdep update`.

## Run

Open four Ubuntu shells. In **each** run:

```bash
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/local_setup.bash
```

Run one command per shell in order:

```bash
ros2 run turtlesim turtlesim_node --ros-args --remap /turtle1/cmd_vel:=/cmd_vel
ros2 run aisd_motion move
ros2 run aisd_vision hands
ros2 run aisd_vision image_publisher
```

Place one hand in the camera view. Sweep the index tip across the image for
steering. Change the horizontal order of the index and pinky to start or stop
forward motion. A stationary hand can still yield a nonzero command. Stop each
process with Ctrl+C. Use Turtlesim for this demo. With no hand detected the
pipeline sends no new velocity command, so stopping depends on the receiver.

## Verify

In a fifth sourced shell, check the graph and the two small message streams:

```bash
ros2 node list
ros2 topic list -t
ros2 topic hz /video_frames
ros2 topic echo /cmd_hand
ros2 topic echo /cmd_vel
```

Use Ctrl+C between streaming commands. For a camera-free check, keep Move and
Turtlesim running, stop Hands, and inject one message from a sourced shell:

```bash
ros2 topic pub --once /cmd_hand aisd_msgs/msg/Hand '{xpinky: 0.20, xindex: 0.70}'
```

Expected on `/cmd_vel`: `linear.x = 0.5`, `angular.z = -0.1`. Replace
`--once` with `-r 5` briefly to make motion easier to see, then stop with Ctrl+C.
