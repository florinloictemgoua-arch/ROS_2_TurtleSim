"""Publish OpenCV webcam frames as ROS image messages."""

import cv2
import rclpy
from cv_bridge import CvBridge
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from sensor_msgs.msg import Image


class ImagePublisher(Node):
    def __init__(self):
        super().__init__('image_publisher')
        camera_index = self.declare_parameter('camera_index', 0).value
        self.bridge = CvBridge()
        self.publisher = self.create_publisher(Image, 'video_frames', 10)

        # Open the guest's first camera by default and sample at about 10 Hz.
        self.capture = cv2.VideoCapture(camera_index)
        if self.capture.isOpened():
            self.timer = self.create_timer(0.1, self.timer_callback)
        else:
            self.get_logger().error(
                f'Cannot open camera {camera_index}. Check camera passthrough '
                'and /dev/video* or set the camera_index parameter.'
            )

    def timer_callback(self):
        received, frame = self.capture.read()
        if not received:
            self.get_logger().warning('Camera read failed.', throttle_duration_sec=5.0)
            return

        # OpenCV returns BGR pixels. Label the encoding and stamp the image.
        message = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')
        message.header.stamp = self.get_clock().now().to_msg()
        self.publisher.publish(message)

    def destroy_node(self):
        self.capture.release()
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = ImagePublisher()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
