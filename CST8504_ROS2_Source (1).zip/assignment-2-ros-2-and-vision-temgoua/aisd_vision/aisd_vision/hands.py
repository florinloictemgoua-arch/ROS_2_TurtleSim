"""Extract horizontal positions of two fingertips from each image."""

import cv2
import mediapipe as mp
import rclpy
from aisd_msgs.msg import Hand
from cv_bridge import CvBridge, CvBridgeError
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from sensor_msgs.msg import Image


INDEX_FINGER_TIP = 8
PINKY_FINGER_TIP = 20


class Hands(Node):
    def __init__(self, detector):
        super().__init__('hands')
        self.detector = detector
        self.bridge = CvBridge()
        self.hand_publisher = self.create_publisher(Hand, 'cmd_hand', 10)
        self.subscription = self.create_subscription(
            Image, 'video_frames', self.listener_callback, 10
        )

    def listener_callback(self, message):
        try:
            bgr = self.bridge.imgmsg_to_cv2(message, desired_encoding='bgr8')
        except CvBridgeError as error:
            self.get_logger().warning(f'Cannot decode image: {error}')
            return

        # MediaPipe takes RGB. Reuse the detector so it can track across frames.
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        rgb.flags.writeable = False
        results = self.detector.process(rgb)
        if not results.multi_hand_landmarks:
            return

        # The assignment uses frame-relative x values from the detected hand.
        landmarks = results.multi_hand_landmarks[0].landmark
        hand = Hand()
        hand.xpinky = landmarks[PINKY_FINGER_TIP].x
        hand.xindex = landmarks[INDEX_FINGER_TIP].x
        self.hand_publisher.publish(hand)


def main(args=None):
    rclpy.init(args=args)
    try:
        with mp.solutions.hands.Hands(
            max_num_hands=1,
            model_complexity=0,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        ) as detector:
            node = Hands(detector)
            try:
                rclpy.spin(node)
            finally:
                node.destroy_node()
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        rclpy.try_shutdown()
